package sm.model.objects;

import sm.model.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Graduate extends Student {

    private String thesisTitle, thesisAdvisor = "";

    public Graduate(){
        super();
    }

    public Graduate(int studentID){
        super(studentID);
    }
    
    public Graduate(String firstName, String lastName, int status, String mentor, String thesisTitle, String thesisAdvisor) {
        super(firstName, lastName, status, mentor);
        this.thesisTitle = thesisTitle;
        this.thesisAdvisor = thesisAdvisor;
    }


    @Override
    public void add() throws SQLException{
        String query = "insert into registrar.student(firstName,lastName,gpa,status,mentor,thesisTitle,thesisAdvisor) values (?,?,?,?,?,?,?)";
        DBConnection.instance().executeAddQuery(query, this);
    }

    @Override
    public String prepareAddStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + thesisTitle + "'").
                replaceFirst("\\?","'" + thesisAdvisor + "'");
    }
    
    @Override
    public String prepareUpdateStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + thesisTitle + "'").
                replaceFirst("\\?","'" + thesisAdvisor + "'").
                replaceFirst("\\?", "" + studentID);
    }
    
    
    //@Override
    public void prepareAddStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, thesisTitle);
        ps.setString(7, thesisAdvisor);
    }
    
    //@Override
    public void prepareUpdateStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, thesisTitle);
        ps.setString(7, thesisAdvisor);
        ps.setInt(8, studentID);
    }

    @Override
    public void populate(ResultSet rs) throws SQLException {
        super.populate(rs);
        this.thesisAdvisor = rs.getString("thesisAdvisor");
        this.thesisTitle = rs.getString("thesisTitle");
    }

    @Override
    public void update() throws SQLException {
        String query = "update registrar.student set firstName = ?, lastName = ?, gpa = ?, status = ?, mentor = ?, thesisTitle = ?, thesisAdvisor = ? where studentID = ?";
        DBConnection.instance().executeUpdateQuery(query, this);
    }

    @Override
    public double calculateTuition(int creditHours) {
        if(status == Status.RESIDENT){
            return creditHours * 300;
        }
        else{
            return creditHours * 350;
        }
    }

    public String getThesisTitle() {
        return thesisTitle;
    }

    public void setThesisTitle(String thesisTitle) {
        this.thesisTitle = thesisTitle;
    }

    public String getThesisAdvisor() {
        return thesisAdvisor;
    }

    public void setThesisAdvisor(String thesisAdvisor) {
        this.thesisAdvisor = thesisAdvisor;
    }


    @Override
    public String toString() {
        return "Graduate{" +
                "thesisTitle='" + thesisTitle + '\'' +
                ", thesisAdvisor='" + thesisAdvisor + '\'' +
                "} " + super.toString();
    }
}
