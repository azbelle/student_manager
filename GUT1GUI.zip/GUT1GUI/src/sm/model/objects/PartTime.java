package sm.model.objects;


import sm.model.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PartTime extends Student {
    private String company = "";

    public PartTime(){
        super();
    }

    public PartTime(int studentID) {
        super(studentID);
    }
    
    
    public PartTime(String firstName, String lastName, int status, String mentor, String company) {
        super(firstName, lastName, status, mentor);
        this.company = company;
    }

    @Override
    public void add() throws SQLException{
        String query = "insert into registrar.student(firstName,lastName,gpa,status,mentor,company) values (?,?,?,?,?,?)";
        DBConnection.instance().executeAddQuery(query, this);
    }

    
    @Override
    public String prepareAddStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + company + "'");
    }
    
    @Override
    public String prepareUpdateStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + company + "'").
                replaceFirst("\\?", "" + studentID);
    }
    
    //@Override
    public void prepareAddStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, company);
    }
    
    //@Override
    public void prepareUpdateStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, company);
        ps.setInt(7, studentID);
    }

    @Override
    public void populate(ResultSet rs) throws SQLException {
        super.populate(rs);
        this.company = rs.getString("company");
    }

    @Override
    public void update() throws SQLException{
        String query = "update registrar.student set firstName = ?, lastName = ?, gpa = ?, status = ?, mentor = ?, company = ? where studentID = ?";
        DBConnection.instance().executeUpdateQuery(query, this);
    }

    @Override
    public double calculateTuition(int creditHours) {
        if(status == Status.RESIDENT){
            return creditHours * 250;
        }
        else{
            return creditHours * 450;
        }
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @Override
    public String toString() {
        return "PartTime{" +
                "company='" + company + '\'' +
                "} " + super.toString();
    }
}
