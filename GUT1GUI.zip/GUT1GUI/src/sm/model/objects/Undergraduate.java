package sm.model.objects;

import sm.model.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Undergraduate extends Student {

    private Level level = Level.freshman;

    public enum Level{
        freshman,
        sophomore,
        junior,
        senior
    };

    public Undergraduate(){
        super();
    }

    public Undergraduate(int studentID) {
        super(studentID);
    }
    
    public Undergraduate(String firstName, String lastName, int status, String mentor, Level level) {
        super(firstName, lastName, status, mentor);
        this.level = level;
    }

    
    @Override
    public void add() throws SQLException {
        String query = "insert into registrar.student(firstName, lastName, GPA, Status, Mentor, level)\n" +
        "values (?,?,?,?,?,?)";
        DBConnection.instance().executeAddQuery(query, this);
    }

    
    @Override
    public String prepareAddStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + level.name() + "'");
    }
    
    @Override
    public String prepareUpdateStatement(String query) throws SQLException {
        return super.prepareAddOrUpdateStatement(query).
                replaceFirst("\\?", "'" + level.name() + "'").
                replaceFirst("\\?", "" + studentID);
    }
    
    //@Override
    public void prepareAddStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, level.name());
    }
    
    //@Override
    public void prepareUpdateStatement(PreparedStatement ps) throws SQLException {
        super.prepareAddOrUpdateStatement(ps);
        ps.setString(6, level.name());
        ps.setInt(7, studentID);
    }

    @Override
    public void populate(ResultSet rs) throws SQLException {
        super.populate(rs);
        this.level = Level.valueOf(rs.getString("level").toLowerCase());
    }

    @Override
    public void update() throws SQLException{
        String query = "update registrar.student set firstName = ?, lastName = ?, gpa = ?, status = ?, mentor = ?, level = ? where studentID = ?";
        DBConnection.instance().executeUpdateQuery(query, this);
    }

    @Override
    public double calculateTuition(int creditHours) {
       if(status == Status.RESIDENT){
           return creditHours * 200;
       }
       else{
           return creditHours * 400;
       }
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }


    @Override
    public String toString() {
        return "Undergraduate{" +
                "level=" + level +
                "} " + super.toString();
    }
}
