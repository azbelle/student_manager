package sm.view;

/**
 * Created with IntelliJ IDEA.
 * User: iguberman
 * Date: 10/6/13
 * Time: 6:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class StudentManager {
    // TODO this should be the GUI
    public static void main(String... args){
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }
    }

}
