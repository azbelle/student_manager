package sm.model.objects;


import sm.model.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

public abstract class Student {
    protected String firstName;
    protected String lastName;
    protected int studentID = 0;
    protected float GPA = 0.0f;
    protected Status status = Status.RESIDENT;
    protected String mentor = "";

    public enum  Status{
        RESIDENT,
        NON_RESIDENT
    }
    public enum Type{
        UNDERGRADUATE,
        GRADUATE,
        PART_TIME;
    }
    
    public static Student getStudent(Type type){
        //Type type = Type.values()[typeInt];
        
        switch(type){
            case UNDERGRADUATE:
                return new Undergraduate();
            case GRADUATE:
                return new Graduate();
            case PART_TIME:
                return new PartTime();
            default:
                System.out.println("Unsupported student type: " + type.name());
        }
        
        return null;
    }
    // default constructor
    public Student(){}
    private static final Logger LOG = Logger.getLogger(Student.class.getName());
    
    
    public Student(int studentID){
        this.studentID = studentID;
    }
    
    public Student(String firstName, String lastName, int status, String mentor) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.status = Status.values()[status];
        this.mentor = mentor;
    }

    public void prepareAddOrUpdateStatement(PreparedStatement ps) throws SQLException {
        // TIS DOESN't WORK in mySQL :((((( 
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setFloat(3, GPA);
        ps.setString(4, status.name());
        ps.setString(5, mentor); 
    }
    
    public String prepareAddOrUpdateStatement(String query) throws SQLException {
        return query.replaceFirst("\\?",  "'" + firstName + "'").
                    replaceFirst("\\?",  "'" + lastName + "'").
        replaceFirst("\\?", "" + GPA).
        replaceFirst("\\?", "'" + status.name() + "'").
        replaceFirst("\\?",  "'" + mentor + "'"); 
    }
    
    public abstract String prepareAddStatement(String query) throws SQLException;
    
    public abstract String prepareUpdateStatement(String query) throws SQLException;
            
    //public abstract void prepareAddStatement(PreparedStatement ps) throws SQLException;
    
    //public abstract void prepareUpdateStatement(PreparedStatement ps) throws SQLException;

    public abstract void add() throws SQLException;

    public void delete() throws SQLException{
        String query = "delete from registrar.student where studentID = " + studentID;
        DBConnection.instance().executeDeleteQuery(query, studentID);
    }

    public void query() throws SQLException {
        String query;
        if(studentID >= 0){ // find by studentID
            query = "select * from registrar.student where studentid = " + studentID;
            
        }
        else{ // find by name
            query = "select * from registrar.student where firstName = '" + firstName + "' and lastName = '" + lastName + "'";
        }
        
        DBConnection.instance().executeSelectQuery(query, this);
        System.out.println(this);
    }
   
    public abstract void update() throws SQLException;

    
    public void populate(ResultSet rs) throws SQLException {
        if (rs.next()) {
            this.firstName = rs.getString("firstName");
            this.lastName = rs.getString("lastName");
            this.studentID = rs.getInt("studentID");
            this.GPA = rs.getFloat("gpa");
            this.status = Status.valueOf(rs.getString("status").toUpperCase());
            this.mentor = rs.getString("mentor");
        } else {
            throw new SQLException("Student doesn't exist!");
        }
    }

    public abstract double calculateTuition(int creditHours);

    public String getMentor() {
        return mentor;
    }

    public void setMentor(String mentor) {
        this.mentor = mentor;
    }

    public int getStatus() {
        return status.ordinal();
    }

    public void setStatus(int status) {
        this.status = Status.values()[status];
    }

    public float getGPA() {
        return GPA;
    }

    public void setGPA(float GPA) {
        this.GPA = GPA;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    

    @Override
    public String toString() {
        return "Student{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", studentID=" + studentID +
                ", GPA=" + GPA +
                ", status=" + status +
                ", mentor='" + mentor + '\'' +
               '}';
    }
}
