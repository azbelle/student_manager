package sm.model;

import sm.model.objects.Student;

import java.lang.String;
import java.sql.*;
import java.sql.PreparedStatement;
import com.mysql.jdbc.Driver;

/** Manage db connection */
public class DBConnection {

    private static DBConnection instance = new DBConnection();

    private Connection connection;

    private DBConnection(){
       init();
    }

    private void init(){} {

        try {
            Class.forName("com.mysql.jdbc.Driver" ).newInstance();
        } catch (Exception ex) {
            System.out.println("Failed to create com.mysql.jdbc.Driver instance");
            System.exit(1);
        }

        try {
            connection =
                    DriverManager.getConnection("jdbc:mysql://localhost/test?" +
                            "user=root&password=gibson");

        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    public static DBConnection instance(){
        return instance;
    }

    public Connection getConnection(){
       return connection;
    }


    private int getCreatedStudentID() throws SQLException {
        ResultSet rs = null;
        PreparedStatement stmt = null;
        String query = "select max(studentID) from registrar.student";
        try {
            
            
            stmt = connection.prepareStatement(query);
           
            rs = stmt.executeQuery(query);
          
            if(rs.next()){
                return rs.getInt(1);
            }
            else{
                return -1;
            }
        }
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore
            }
        }
    }
    public void executeAddQuery(String query, Student student) throws SQLException {
        PreparedStatement stmt = null;
        try {
            String preparedQuery = student.prepareAddStatement(query);
            System.out.println("Add query: " + preparedQuery);
            stmt = connection.prepareStatement(preparedQuery);
            
            stmt.executeUpdate(preparedQuery);
        }
        finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { }
            }
        }
        
        student.setStudentID(this.getCreatedStudentID());
    }

    public void executeUpdateQuery(String query, Student student) throws SQLException {
        PreparedStatement stmt = null;
        try {
            String preparedQuery = student.prepareUpdateStatement(query);
            System.out.println("Update query: " + preparedQuery);
            stmt = connection.prepareStatement(preparedQuery);
            //student.prepareUpdateStatement(stmt);
            stmt.executeUpdate(preparedQuery);
        }
        finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { }
            }
        }
    }
    
    public void executeDeleteQuery(String query, int studentID) throws SQLException {
        PreparedStatement stmt = null;
        try {
            stmt = connection.prepareStatement(query);
            //stmt.setInt(1, studentID);
            stmt.executeUpdate(query);
        }
        finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { }
            }
        }
    }

    /* TODO PLEASE NOTE: I'm not using variable substitutions in my prepared statements because 
     * for some strange reason prepared statements with "?" don't work no matter what I do
     */
    public void executeSelectQuery(String query, Student student) throws SQLException {
        ResultSet rs = null;
        PreparedStatement stmt = null;
        try {
            stmt = connection.prepareStatement(query);
            
            //stmt.setInt(1, student.getStudentID());
            
            rs = stmt.executeQuery(query);
          
            student.populate(rs);
        }
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore
            }
        }
    }
}
