package sm.controller;

import java.sql.SQLException;
import sm.view.StudentManagerGUI;
import sm.model.DBConnection;
import sm.model.objects.Student;

public class StudentManager {
    
    static Student student;
    
    // TODO this should be the GUI
    public static void main(String... args){
       StudentManagerGUI.init();
    }
    
    public static Student findStudent(Student.Type type, int studentID) throws SQLException{
         student = Student.getStudent(type);
            student.setStudentID(studentID);
            student.query();
            return student;
    }
    
     public static Student findStudent(Student.Type type, String firstName, String lastName) throws SQLException{
         student = Student.getStudent(type);
            student.setFirstName(firstName);
            student.setLastName(lastName);
            student.query();
            return student;
    }
     
    public static Student getStudent(){
        return student;
    }

    public static void setStudent(Student newStudent) {
       student = newStudent;
    }

}
